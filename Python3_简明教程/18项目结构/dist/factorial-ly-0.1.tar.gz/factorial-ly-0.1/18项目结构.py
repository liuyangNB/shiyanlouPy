"""

本实验阐述了一个完整的 Python 项目结构，你可以使用什么样的目录布局以及怎样发布软件到网络上。

知识点
    创建项目，编写 __init__ 文件
    使用 setuptools 模块，编写 setup.py 和 MANIFEST.in 文件
    创建源文件的发布版本
    项目注册&上传到 PyPI
"""

