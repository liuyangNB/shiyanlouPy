from factorial import fact
__all__=[fact,]